print("введите пароль")
flag=input()

fib = lambda n: fib(n - 1) + fib(n - 2) if n > 2 else 1

if len(flag)==11:
    sum=0
    for i in range(4,7):
        if fib(i-3)!=int(flag[i]):
            break
        sum+=int(flag[i])
     
    if (fib(3)+2==sum):
        a=flag[0]
        for i in range(1,4):
            a+=flag[i]
        b=flag[7]
        for i in range(8,11):
            b+=flag[i]
        if b==a[::-1]:
            if a=="flag":
                print("YOU WIN")
                print("CTF{",flag,"}")
            else:
                print("!!!!!!")
        else:
            print("you looose")
    else:
        print("NOOOOO")
else:
    print("WRONG!!!")    
