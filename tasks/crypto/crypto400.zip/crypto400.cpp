#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <vector>
#include <cmath>

using namespace std;


int main()
{
    vector<int> sum_letter;
    int n;
    int num, count=1, temp=0, ok=0, check=1;
    double so;
    string temp_text, message, encrypt;
    cout << "Enter the message size" << endl;
    cin >> n;
    cin >> message;
    cin >> temp_text;
    for(int i=0;i<n;++i){
        int int_key=(int)temp_text[i];
        int int_message=(int)message[i];
        if(int_key>int_message){
            so=sin(int_key-int_message)*10000;  
            num=abs(so); // double to int
            while (ok<4){       
                temp += num%10; 
                num/=10;
                ++ok;
            }
            sum_letter.push_back(temp);
            temp=0;
            ok=0;
        }
    }  
    for(int i=0;i<sum_letter.size();++i){
        sum_letter[i]+=97;
        if(sum_letter[i]<123)
            encrypt+=(char)sum_letter[i];
        else{
            sum_letter[i]-=58;
            encrypt+=(char)sum_letter[i];
        }
    }
    cout << encrypt <<endl;
    system("pause");
}
