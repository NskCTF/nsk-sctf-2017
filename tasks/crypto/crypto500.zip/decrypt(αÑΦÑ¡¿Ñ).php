<?php //CryptoZLO decrypt
$text = file_get_contents("0");
echo "<br>".strlen($text)."<br>";
echo (255*3)."<br>";
echo "<br>".(strlen($text)-(255*3))."<br>";
$shifrotext = NULL;
$decrypttext = NULL;
$count = (strlen($text)-(255*3));
$half = $count/2;
$flag = NULL;
//first part
for($i=0;$i<$half/2;$i++){
	$shifrotext .= $text[$i];
}
echo "<br>".$shifrotext;
$decrypttext = decrypt1(0,($half/2),$shifrotext);
echo "<br>".$decrypttext;
$flag .=$decrypttext;
//second part
for($i=($half/2+255);$i<($half+255);$i++){
	$shifrotext .= $text[$i];
}
echo "<br>".$shifrotext;
$decrypttext= decrypt2($half/2,$half,$shifrotext,0,$half/2);
echo "<br>".$decrypttext;
$flag .=$decrypttext;
//third part
for($i=($half+255*2);$i<($half+255*2+$half/2);$i++){
	$shifrotext .= $text[$i];
}
echo "<br>".$shifrotext;
$decrypttext = decrypt1($half,($half/2+$half),$shifrotext);
echo "<br>".$decrypttext;
$flag .=$decrypttext;
//fourth part
for($i=($half+$half/2+255*3);$i<(255*3+$count);$i++){
	$shifrotext .= $text[$i];
}
echo "<br>".$shifrotext;
$decrypttext= decrypt2(($half+$half/2),$count,$shifrotext,$half,($half+$half/2)); 
echo "<br>".$decrypttext;
$flag .=$decrypttext;
echo "<br>".$flag;

function decrypt1($start,$end,$text){
	$shifr1 = NULL;
	$NewTEXT = NULL;
	$sdvig=$end-$start;
	for($i=$start; $i<$end; $i++){
		if($i%2==0){
			$NewTEXT[$i]= ord($text[$i])+$sdvig;
			$shifr1 .= chr($NewTEXT[$i]);
		}
		elseif($i%2==1){
			$NewTEXT[$i]= ord($text[$i])-$sdvig;
			$shifr1 .= chr($NewTEXT[$i]);
		}
	}
	return $shifr1;
}

function decrypt2($start,$end,$text,$oldstart,$oldend){
	$shifr2 = NULL;
	$oldtext = NULL;
	$NewTEXT2 = NULL;
	$g = $oldstart;
	for($j=$oldstart; $j<($oldend); $j++){
		$oldtext[$j] = $text[$j];
	}
	for($i=$start; $i<$end; $i++){
		$NewTEXT2[$i]=ord($text[$i])-ord($oldtext[$g++]);
		$shifr2 .= chr($NewTEXT2[$i]);
		}	
	return $shifr2;
}
?>
