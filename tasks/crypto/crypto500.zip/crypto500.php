<?php 
$lib='test';
$count = strlen($lib);
$default = 0;
$half = $count/2;
$shifrotext = NULL;
$shifrotextsmusorom = NULL;
for($i=$default; $i<$half/2; $i++){$text[$i]=$lib[$i];}
$shifrotext .=crypto1($default,$half/2,$text);
$shifrotextsmusorom .=crypto1($default,$half/2,$text) .musor();
for($i=$half/2; $i<$half; $i++){$text[$i]=$lib[$i];}
$shifrotext .=crypto2($half/2,$half,$text,$default,$half/2,$shifrotext);
$shifrotextsmusorom .=crypto2($half/2,$half,$text,$default,$half/2,$shifrotext) .musor();
for($i=$half; $i<($half+$half/2); $i++){$text[$i]=$lib[$i];}
$shifrotext .=crypto1($half,($half+$half/2),$text);
$shifrotextsmusorom .=crypto1($half,($half+$half/2),$text) .musor();
for($i=($half+$half/2); $i<$count; $i++){$text[$i]=$lib[$i];}
$shifrotext .=crypto2(($half+$half/2),$count,$text,$half,($half+$half/2),$shifrotext);
$shifrotextsmusorom .=crypto2(($half+$half/2),$count,$text,$half,($half+$half/2),$shifrotext);
echo $shifrotextsmusorom."<br>";//
function &crypto1($start,$end,$text){
	$shifr1 = NULL;
	$NewTEXT = NULL;
	$sdvig=$end-$start;
	for($i=$start; $i<$end; $i++){
		if($i%2==0){$NewTEXT[$i]= ord($text[$i])-$sdvig;$shifr1 .= chr($NewTEXT[$i]);}
		elseif($i%2==1){$NewTEXT[$i]= ord($text[$i])+$sdvig;$shifr1 .= chr($NewTEXT[$i]);}
	}
	return $shifr1;
}
function &crypto2($start,$end,$text,$oldstart,$oldend,$kostil){
	$shifr2 = NULL;
	$oldtext = NULL;
	$NewTEXT2 = NULL;
	$g = $oldstart;
	for($j=$oldstart; $j<($oldend); $j++){$oldtext[$j] = $kostil[$j];}
	for($i=$start; $i<$end; $i++){$NewTEXT2[$i]=ord($text[$i])+ord($oldtext[$g++]);$shifr2 .= chr($NewTEXT2[$i]);}	
	return $shifr2;
}
function &musor(){
	$musor = NULL;
	for($i=0; $i<255; $i++){
		$musor.=chr(rand(33,126));
	}
	return $musor;
}
?>
